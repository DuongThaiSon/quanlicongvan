<footer class="footer">
    © 2019 Quản lý công văn by Dương Thái Sơn, Đinh Văn Tuấn, Đỗ Văn Dũng
</footer>
<?php /**PATH D:\xampp\htdocs\quanlicongvan\resources\views/viewer/layout/footer.blade.php ENDPATH**/ ?>