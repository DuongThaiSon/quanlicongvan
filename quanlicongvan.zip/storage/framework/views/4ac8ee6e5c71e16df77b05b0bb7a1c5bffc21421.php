<?php $__env->startSection('title'); ?>
<title>Chi Tiết</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<body>
    <div class="bg-white main-content">
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="viewer/congvanden/danhsach">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="#">Thông báo</a></li>
        </ul>
        <div class="doc-main">
            <div class="row">
                <div class="col-lg-9">
                    <div class="doc-main_content">
                        <div class="top-content">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="title">
                                        <?php echo e($chitiet->documentary_send->name); ?>

                                    </div>
                                    <div class="subtitle">
                                        <span><?php echo e($chitiet->documentary_send->User->name); ?> - </span>
                                        <span><?php echo e($chitiet->documentary_send->User->email); ?> - </span>
                                        <span>lúc </span>
                                        <span><?php echo e($chitiet->documentary_send['updated_at']->format('H:i')); ?> - </span>
                                        <span><?php echo e($chitiet->documentary_send['updated_at']->format('d/m/Y')); ?></span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="document-content">
                            <?php echo $chitiet->documentary_send->content; ?>

                        </div>
                        <div class="files">
                            <div class="subheader">
                                Tài liệu
                            </div>
                            <div class="file">
                                <div class="file-header">
                                    <div class="row">
                                        <div class="col-lg-10">
                                            <div class="file-name">
                                                <?php echo e($chitiet->documentary_send->file); ?>

                                            </div>
                                            <div class="file-info">
                                                <?php echo e(number_format($chitiet->documentary_send->storage/1048576,2)); ?>KB
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <a class="btn-download" href="download/<?php echo e($chitiet->documentary_send->file); ?>"
                                                title="Tải xuống" download="<?php echo e($chitiet->documentary_send->file); ?>">
                                                <i class="fas fa-file-download"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="file-display">
                                    <object data="BROCHURE OFFICE.pdf" type="application/pdf">
                                        <iframe src=""></iframe>
                                    </object>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-lg-3">
                    <div class="doc-side">
                        <!-- <div class="box-info">
                            <div class="form-group">
                                <label for="">Loại công văn</label>
                                <div class="type">
                                    <span><?php echo e($chitiet->documentary_send->type_documentary->name); ?> Nội bộ</span>
                                </div>
                            </div>
                        </div> -->
                        <div class="box-seen">
                            <div class="title">
                                <span>33</span>
                                <span> người đã xem.</span>
                            </div>
                            <div class="avatars">
                                <div class="image">
                                    <img src="pmhdv/images/1.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/2.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/3.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/4.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/5.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/6.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/7.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/1.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/2.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/3.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/4.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/5.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/6.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/7.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/1.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/2.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/3.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/4.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/5.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/6.jpg" alt="">
                                </div>
                                <div class="image">
                                    <img src="pmhdv/images/7.jpg" alt="">
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="comment">
                            <div class="box-post">
                                <div class="user">
                                    <div class="avatar float-left">
                                        <img src="pmhdv/images/4.jpg" alt="" class="img-circle" width="50">
                                    </div>
                                    <div class="name float-left ml-3">
                                        <em>Nguyễn Quỳnh</em>
                                        <div class="info">
                                            <span>BC</span>
                                            <span>@quynhnt</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                                <div class="form-post mt-4">
                                    <form action="">
                                        <textarea name="" id="" placeholder="Viết bình luận của bạn"></textarea>
                                    </form>
                                </div>
                            </div>
                            <div class="box-comment">
                                <div class="box-cmt_header">
                                    <span>4</span> Thảo luận
                                </div>
                                <div class="list-cmt mt-4">
                                    <div class="post">
                                        <div class="mb-4">
                                            <div class="user">
                                                <div class="avatar float-left">
                                                    <img src="pmhdv/images/4.jpg" alt="" class="img-circle" width="50">
                                                </div>
                                                <div class="name float-left ml-3">
                                                    <em>Nguyễn Quỳnh</em>
                                                    <div class="info">
                                                        <span>10:26</span>
                                                        <span>21/6/2019</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clear"></div>
                                            <div class="cmt-text mt-4">
                                                <em>Đọc quyết định mới nhé</em>
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <div class="user">
                                                <div class="avatar float-left">
                                                    <img src="pmhdv/images/4.jpg" alt="" class="img-circle" width="50">
                                                </div>
                                                <div class="name float-left ml-3">
                                                    <em>Nguyễn Quỳnh</em>
                                                    <div class="info">
                                                        <span>10:26</span>
                                                        <span>21/6/2019</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clear"></div>
                                            <div class="cmt-text mt-4">
                                                <em>Đọc quyết định mới nhé</em>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('viewer.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\quanlicongvan\resources\views/viewer/congvanden/chitiet.blade.php ENDPATH**/ ?>