<?php $__env->startSection('title'); ?>
<title>Trang chủ</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="bg-white main-content">
    <div class="sub-header">
        <div class="row">
            <div class="col-lg-6">
                <!-- <div class="title">Trường đại học công nghiệp </div> -->

                <ul class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a class="c-black" href="viewer/congvan/luutru">Lưu trữ</a></li>

                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tp == $type): ?>

                    <li class="breadcrumb-item"><a class="c-black" href="viewer/congvan/luutru/<?php echo e($type->id); ?>"><?php echo e($tp->name); ?></a></li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-lg-6">
                <div class="search text-right position-relative">
                    <form action="<?php echo e(route('get-timcv',$type->id)); ?>" method="get">
                        <input type="text" placeholder="Nhập tên văn bản" name="timcongvan" class="input-search"
                            autocomplete="off">
                        <button type="submit" class="btn-search btn-info">
                            <i class="fa fa-search"></i>
                        </button>
                        <div class="clear"></div>
                        <div class="advance d-none">
                            <div class="title position-relative">
                                <span class="text-uppercase">Bộ lọc nâng cao</span>
                            </div>
                            <div class="form-group">
                                <label for="">Thời gian</label>
                                <input type="date" name="thoigian" id="" class="form-control">
                            </div>
                            <div>
                                <button type="submit" class="btn btn-info mt-2 btn-search-advance">Tìm kiếm</button>
                                <button type="button" class="btn btn-discard mt-2">Hủy bỏ</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="news">
        <div class="them-luutru">
            <a href="<?php echo e(route('get-taocv',$type->id)); ?>" class="btn-them" style="background-color:green;">
                <span class="icon-holder">
                    <i class="fas fa-plus"></i>
                </span>
                <span class="sidebar-text">Tải lên</span>
            </a>
        </div>
        <div class="row pl-3 pr-3">
            <?php $__currentLoopData = $congvans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $congvan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-md-3 col-sm-4">
                <div class="news-item">
                    <div class="news-item--img position-relative">

                        <?php
                            $name = explode(".",$congvan->file_code);
                            
                        ?>

                        <a href="<?php echo e(route('get-xemcv',$congvan->id)); ?>">
                            <?php if($name[1] == "jpg" || $name[1] == "png" ||$name[1] == "PNG"): ?>

                            <img class="img-fluid" src="pmhdv/images/<?php echo e($congvan->file_code); ?>" alt="">
                            <?php else: ?>
                            <?php if($name[1] == "docx" || $name[1] == "pdf"): ?>

                            <img class="img-fluid" src="pmhdv/images/<?php echo e($congvan->file_jpg); ?>" alt="">
                            <?php else: ?>
                            <?php if($name[1] == "zip"||$name[1] == "jar"): ?>
                            <img class="img-fluid" src="pmhdv/images/winrar.jpg" alt="">
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php endif; ?>
                        </a>

                        <div class="news-icon d-none">
                            <div class="news-caret">
                                <div class="dropdown">
                                    <a href="" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fas fa-angle-down"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-left">
                                        <div class="news-icon-item">
                                            <a href="<?php echo e(route('get-xoacv',$congvan->id)); ?>" title="Xóa">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                        <div class="news-icon-item">
                                            <a href="pmhdv/images/<?php echo e($congvan->file_code); ?>" title="Tải xuống"
                                                download="<?php echo e($congvan->file_code); ?>">
                                                <i class="fas fa-file-download"></i>
                                            </a>
                                        </div>
                                        <div class="news-icon-item">
                                            <a href="" title="Sửa">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="news-item-text">
                        <div class="news-type">
                            <div class="row pl-0 mb-2">
                                <div class="col-lg-7 text-left">
                                    <div class="tag">
                                        <i class="fas fa-tags"></i>
                                        <span><?php echo e($congvan->type_documentary->name); ?></span>
                                    </div>
                                </div>
                                <div class="col-lg-5 pl-0">
                                    <div class="news-info d-flex justify-content-end">
                                        <?php
                                        $check_file = explode(".",trim($congvan->file_code));
                                        ?>
                                        <?php if($check_file[1] == "pdf"): ?>

                                        <div class="pdf file-fix">
                                            <i class="far fa-file-pdf"></i>
                                        </div>
                                        <?php else: ?>
                                        <?php if($check_file[1] == "doc" || $check_file[1] == "docx"): ?>
                                        <div class="word file-fix">
                                            <i class="fas fa-file-word"></i>
                                        </div>
                                        <?php else: ?>
                                        <?php if($check_file[1] == "xlsx" || $check_file[1] == "xlsm"): ?>
                                        <div class="excel file-fix">
                                            <i class="fas fa-file-excel"></i>
                                        </div>
                                        <?php else: ?>
                                        <span class="jpg file-fix">
                                            <i class="fas fa-file-image"></i>
                                        </span>
                                        <?php if($check_file[1] =="zip"): ?>
                                        <span>Zip</span>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        <?php endif; ?>

                                        <?php endif; ?>
                                        <div class="storage">
                                            <?php echo e(number_format($congvan->storage/1048576,2)); ?>MB
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="news-avatar">
                            <div class="dropdown">
                                <div class="author-figure dropdown-toggle float-left mb-0 mr-3" data-toggle="dropdown">
                                    <a href="">
                                        <img src="pmhdv/images/<?php echo e($congvan->User->avatar_code); ?>">
                                    </a>
                                </div>
                                <div class="box-user-info mt-1 dropdown-menu">
                                    <div class="box-user-info--name">
                                        <p><?php echo e($congvan->User->name); ?></p>
                                        <p class="m-0">
                                            <span><?php echo e($congvan->User->email); ?></span>
                                            <span> · </span>
                                            <span><?php echo e($congvan->User->role->name); ?></span>
                                            <?php if($congvan->User->id_major!=0): ?>
                                            <span><?php echo e($congvan->User->major->name); ?></span>
                                            <?php endif; ?>
                                        </p>
                                    </div>

                                </div>
                            </div>
                            <div class="c-light">
                                <span><?php echo e($congvan['created_at']->format('H:i')); ?> </span>
                                <span> - </span>
                                <span><?php echo e($congvan['created_at']->format('d/m/Y')); ?></span>

                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="news-name">
                            <a href="<?php echo e(route('get-xemcv',$congvan->id)); ?>">
                                <h4><?php echo e($congvan->name); ?>

                                </h4>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="pag-link"><?php echo e($congvans->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('viewer.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\quanlicongvan\resources\views/viewer/luutru/chitiet.blade.php ENDPATH**/ ?>