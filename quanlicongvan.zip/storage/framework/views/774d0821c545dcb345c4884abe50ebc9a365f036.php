<section class="header position-relative">
    <div class="container-fluid fix-container">
        <div class="row">
            <div class="col-6">
                <a href="javascript:void(0)" class="btn-toggle">
                    <i class="fas fa-bars"></i>
                </a>
                <div class="logo">
                    <a href="viewer/congvanden/danhsach">
                        <img src="pmhdv/images/logo-icon.png" alt="">
                        <span class="logo-text">
                            <b>Elegant</b>
                            <em>Office</em>
                        </span>
                    </a>
                </div>
            </div>
            <div class="col-6">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown text-right">
                        <a href="" class="nav-link dropdown-toggle text-muted waves-effect waves-dark"
                            data-toggle="dropdown">
                            <img src="pmhdv/images/<?php echo e(Auth::user()->avatar_code); ?>" class="img-circle" width="30" alt="">
                            <span>
                                <i class="fas fa-caret-down"></i>
                            </span>
                        </a>
                        <?php if(Auth::check()): ?>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a href="viewer/user/thongtincanhan" class="dropdown-item">Thông tin cá nhân</a>
                            <div class="line"></div>
                            <a href="logout" class="dropdown-item">Đăng xuất</a>
                        </div>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\xampp\htdocs\quanlicongvan\resources\views/viewer/layout/header.blade.php ENDPATH**/ ?>