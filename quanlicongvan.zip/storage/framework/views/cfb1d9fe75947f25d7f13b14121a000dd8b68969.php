<?php $__env->startSection('title'); ?>
<title>Thêm công văn</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="bg-white main-content">
    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($err); ?><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <?php if(session('thongbao')): ?>
    <div class="alert alert-success">
        <?php echo e(session('thongbao')); ?>

    </div>
    <?php endif; ?>
    <div class="container-fluid">

        <div class="main-form">
            <h5 class="form-create-title pt-4 mb-4">
                <ul class="breadcrumb">

                    <li class="breadcrumb-item"><a href="viewer/congvan/luutru">Lưu trữ</a></li>

                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tp == $type): ?>

                    <li class="breadcrumb-item"><a href="viewer/congvan/luutru/<?php echo e($type->id); ?>"><?php echo e($tp->name); ?></a></li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('get-taocv',$type)); ?>">Tải lên</a></li>
                </ul>
            </h5>
            <form action="<?php echo e(route('post-taocv',$type)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- <div class="row">
                    <div class="col-lg-6"> -->
                <div class="box-create-left create-section">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="">Tiêu đề<sup>*</sup></label>
                                <input type="text" placeholder="Tiêu đề" name="tieude">
                            </div>

                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="">Tệp đính kèm<sup>*</sup></label>
                                <input type="file" name="teptin">
                            </div>

                        </div>
                    </div>

                    <!-- </div>
                    </div> -->

                </div>
                <button type="submit" class="btn-add continue">Lưu trữ</button>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('viewer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\quanlicongvan\resources\views/viewer/congvan/taomoi.blade.php ENDPATH**/ ?>